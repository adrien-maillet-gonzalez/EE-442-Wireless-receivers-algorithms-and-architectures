clc,clear

% load the received samples
load diversity_task

% Constellation and pilot symbol

pilot_symb = (1+1j)/sqrt(2);

% ToDo 1.1:
constellation = [1+1j -1+1j 1-1j -1-1j]*1/sqrt(2);
h1_est = signal(1)/pilot_symb;

% ToDo 1.2:


rx1 = signal(2:113)/h1_est;

msg1 = decode_msg(rx1,constellation);

% ToDo 1.3:

h2_est = signal(1001)/pilot_symb;

rx2 = signal(1002:1113)/h2_est;

msg2 = decode_msg(rx2,constellation);


% ToDo 1.4
theta_1 = angle(h1_est);
theta_2 = angle(h2_est);

theta = [theta_1 theta_2];

magnitude_1 = abs(h1_est);
magnitude_2 = abs(h2_est);

magnitude = [magnitude_1 magnitude_2];

h_conj = exp(-1j*theta).*magnitude;

combined_payloads = [signal(2:113); signal(1002:1113)];

rx_comb = h_conj/norm(h_conj)^2 * combined_payloads;

msg_comb = decode_msg(rx_comb,constellation);
    
% Plot and save the constellation
% ToDo 1.5
% subplot containing the received symbols
subplot(1,2,1)
plot(rx_comb, '.','Markersize',12),hold on
    
grid on,hold on,axis square
    
plot(constellation,'x','Markersize',12)
xlabel("Real")
ylabel("Imag")

title({strcat("Message frame 1: ",msg1);
       strcat("Message frame 2: ",msg2);
       strcat("Message combined: ",msg_comb)})

% subplot printing the decoded message strings
subplot(1,2,2)
axis off
text(0.2, 0.5,{strcat("Message frame 1: "+newline,msg1);newline; ...
            strcat("Message frame 2: "+newline,msg2);newline; ...
            strcat("Message combined: "+newline,msg_comb)}, 'Units', 'normalized','Fontname','Monospaced', 'Interpreter', 'none');
set(gcf, 'Position', [100, 100, 1000, 500]);

saveas(gcf,'P2T1_const.png')



